# GameOfLife

Implementation of Conway's game of life.

To use, run the executable: ./GameOfLife

Version from 2021-11-28
